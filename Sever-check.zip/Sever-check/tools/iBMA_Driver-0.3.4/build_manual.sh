#!/bin/bash

export DRV_VERSION=0.3.4
export KMOD_NAME=ibmadriver

build_ko()
{
    cd ${BIN_DIR}
    rm -f *.ko

    modules=("edma_drv" "cdev_drv" "veth_drv" "kbox_drv" "cdev_veth_drv")
    # cdev module should not be supported by euleros 
    if [[ $1 =~ "euleros" ]]; then
        unset modules[4]
    fi

    for module in "${modules[@]}"; do
        cd ${module}
        ret=$(make)
        if [ $? -ne 0 ]; then
            echo "Build edma_drv failed, message:${ret}."
            return 1
        fi
        mv *.ko ..
        cd ..
    done

    strip --strip-debug *.ko

    echo "Build driver ko successfully."
    return 0
}
cd $(dirname ${0})
BIN_DIR=$(pwd)
ARCH_TYPE=$(uname -m)

PACKAGE_TYPE=""
KVER=$(uname -r)
PUBLISHER=local
OS_VERISON=local
FLAVOR=$(echo ${KVER} |awk -F- '{print $NF}')
kerv_array=()

UNSAFE_COMPILATION_SYSTEM_ARRAY=("kylin" "uos" "neokylin")
DRIVER_KO_DIR_ARRAY=(cdev_drv cdev_veth_drv edma_drv kbox_drv veth_drv)

set_env()
{
    PUBLISHER=$(echo "$1" | cut -d '-' -f 1)
    OS_VERISON=$(echo "$1" | cut -d '-' -f 2)
    if [ -f /etc/os-release ] && [ -n "$(grep -woE 'Ubuntu|Debian|uos' /etc/os-release)" ]; then
        PACKAGE_TYPE="deb"
    else
        PACKAGE_TYPE="rpm"
        kerv_array=($(uname -r 2>/dev/null))
    fi

    SYSTEM_INFO=$(uname -m)
    if [[ $1 =~ "euleros" ]]; then
        sed -i "s/cdev_veth_drv//g" ${BIN_DIR}/Makefile
        sed -i "/Source4/d" ${BIN_DIR}/linux_pack/rpm/iBMA_driver.spec
        sed -i "/SOURCE4/d" ${BIN_DIR}/linux_pack/rpm/iBMA_driver.spec
        sed -i "s/\"cdev_veth_drv\"//g" ${BIN_DIR}/linux_pack/rpm/iBMA_driver.spec
    fi

    # remove the "-fstack-protector-all" option in Makefile if the "-fstack-protector-all" option is not supported by this os
    for os_type in ${UNSAFE_COMPILATION_SYSTEM_ARRAY[@]}
    do
        if [[ $1 =~ ${os_type} ]]; then
            for driver_dir in ${DRIVER_KO_DIR_ARRAY[@]}
            do
                sed -i 's/EXTRA_CFLAGS += -Wformat=0 -fstack-protector-all/EXTRA_CFLAGS += -Wformat=0/g' ${BIN_DIR}/${driver_dir}/Makefile
            done
            break
        fi
    done
}

build_driver_rpm()
{
    echo "Start build rpm..."

    tmp_str=$(cat /etc/passwd | grep -w rpmbuilder)
    if [ -z "$tmp_str" ];then
       useradd -m rpmbuilder
    fi

    mkdir -pv -m 777 /home/rpmbuilder/rpmbuild

    cd /home/rpmbuilder/
    echo "%_topdir /home/rpmbuilder/rpmbuild" > .rpmmacros
    rm -rf ./rpmbuild/{BUILD,BUILDROOT,RPMS,SOURCES,SPECS,SRPMS}

    ret=$(mkdir -pv -m 777 ./rpmbuild/{BUILD,BUILDROOT,RPMS,SOURCES,SPECS,SRPMS} 2>&1)
    if [ $? -ne 0 ]; then
        "mkdir return ${ret}."
    fi

    cp -f $BIN_DIR/*.ko   /home/rpmbuilder/rpmbuild/SOURCES/

    if [ $PUBLISHER = "sles" ]; then
        cp -f $BIN_DIR/linux_pack/rpm/fileslist  /home/rpmbuilder/rpmbuild/SOURCES/fileslist
    fi

    cp -f $BIN_DIR/linux_pack/rpm/iBMA_driver.spec  /home/rpmbuilder/rpmbuild/SPECS/iBMA_driver.spec
    chown -R rpmbuilder /home/rpmbuilder
    chmod 777 /home/rpmbuilder/rpmbuild/SPECS/iBMA_driver.spec

    if [ $PUBLISHER = "sles" ] || [ $PUBLISHER = "citrix" ]; then
        echo "Start build $KVER"

        ret=$(su - rpmbuilder -c "cd /home/rpmbuilder/rpmbuild
        rpmbuild -bb  --define 'version_var $DRV_VERSION'  --define 'kmod_name iBMA_driver' --define 'kernel $KVER' --define 'os_type $PUBLISHER' --define 'os_version $OS_VERISON' --define 'os_flavor $FLAVOR' SPECS/iBMA_driver.spec 2>&1")
        if [ $? -ne 0 ]; then
            echo "Build rpm failed, message:${ret}."
        else
            echo "Build rpm successfully."
        fi
    else
        for ((i=0;i<${#kerv_array[@]};i++))
        do
            echo "Start build ${kerv_array[$i]}"
            ret=$(su - rpmbuilder -c "cd /home/rpmbuilder/rpmbuild
            rpmbuild -bb  --define 'version_var $DRV_VERSION'  --define 'kmod_name iBMA_driver' --define 'kernel ${kerv_array[$i]}' --define 'os_type $PUBLISHER' --define 'os_version $OS_VERISON' --define 'os_flavor $FLAVOR' SPECS/iBMA_driver.spec" 2>&1)
            if [ $? -ne 0 ]; then
                echo "Build ${kerv_array[$i]} failed, message:${ret}."
                return 1
            else
                echo "Build ${kerv_array[$i]} successfully."
            fi
        done
    fi

    mv /home/rpmbuilder/rpmbuild/RPMS/${ARCH_TYPE}/*.rpm $BIN_DIR
    return 0
}

build_driver_deb()
{
    echo "Start build deb..."

    rm -rf $BIN_DIR/linux_pack/deb/$KMOD_NAME/lib/modules/*
    mkdir -p $BIN_DIR/linux_pack/deb/$KMOD_NAME/lib/modules/$KVER/updates/$KMOD_NAME

    cp -f $BIN_DIR/*.ko   $BIN_DIR/linux_pack/deb/$KMOD_NAME/lib/modules/$KVER/updates/$KMOD_NAME/

    architecture=$(dpkg --print-architecture)
    sed -i "/^Version/c Version: $DRV_VERSION"  $BIN_DIR/linux_pack/deb/$KMOD_NAME/DEBIAN/control
    sed -i "/^Architecture/c Architecture: $architecture"  $BIN_DIR/linux_pack/deb/$KMOD_NAME/DEBIAN/control
    chmod -R 775 $BIN_DIR/linux_pack/deb/$KMOD_NAME/DEBIAN/
    cd $BIN_DIR/linux_pack/deb

    ret=$(dpkg -b $KMOD_NAME  $KMOD_NAME-$KVER-$DRV_VERSION-$PUBLISHER$OS_VERISON.$architecture.deb 2>&1)
    if [ $? -ne 0 ]; then
        echo "Build deb failed, message:${ret}."
        return 1
    else
        echo "Build deb successfully."
    fi

    mv $BIN_DIR/linux_pack/deb/$KMOD_NAME-$KVER-$DRV_VERSION-$PUBLISHER$OS_VERISON.$architecture.deb  $BIN_DIR
    return 0
}

build_driver_sles()
{
    echo "Start build sles driver..."
    local exclude_flavor="xen"

    # need to compile xen kernel package on UVP
    if [ "xen" = ${FLAVOR} ];then
        exclude_flavor="default"
    fi

    rm -rf iBMA_driver-${DRV_VERSION}

    # make sles build sources
    mkdir iBMA_driver-${DRV_VERSION}
    cp -rf edma_drv/ kbox_drv/ veth_drv/ cdev_drv/ cdev_veth_drv/ iBMA_driver-${DRV_VERSION}
    if [[ -d "../include" ]]; then
        cp -rf ../include iBMA_driver-${DRV_VERSION}
    else
        cp -rf include iBMA_driver-${DRV_VERSION}
    fi
    tar -jcf iBMA_driver-${DRV_VERSION}.tar.bz2 iBMA_driver-${DRV_VERSION}

    rm -rf /usr/src/packages/SOURCES/iBMA_driver-${DRV_VERSION}.tar.bz2
    rm -rf /usr/src/packages/SOURCES/kernel-module-subpackage-sles12
    rm -rf /usr/src/packages/SPECS/SLES_iBMA_driver.spec

    cp -f $BIN_DIR/iBMA_driver-${DRV_VERSION}.tar.bz2 /usr/src/packages/SOURCES/
    cp -f $BIN_DIR/linux_pack/rpm/kernel-module-subpackage-sles12 /usr/src/packages/SOURCES/
    cp -f $BIN_DIR/linux_pack/rpm/SLES_iBMA_driver.spec /usr/src/packages/SPECS/

    ret=$(rpmbuild -ba --define "exclude_flavor $exclude_flavor" /usr/src/packages/SPECS/SLES_iBMA_driver.spec 2>&1)
    if [ $? -ne 0 ]; then
        echo "Build sles driver failed, message:${ret}."
        return 1
    fi

    driver_path=$(echo "${ret}" | grep "iBMA_driver-kmp-.*.rpm" | grep -v "preempt" | awk '{print $2}')
    if [ -z "${driver_path}" ]; then
        echo "Not found the driver files in /usr/src/packages/RPMS/x86_64/."
        return 1
    fi

    # the driver add sles info
    driver_name=${driver_path##*/}
    # delete last two .
    driver_name=${driver_name%.*.*}
    new_driver_name="${driver_name}-${1}.$(uname -p).rpm"

    mv ${driver_path} ${BIN_DIR}/${new_driver_name}

    echo "Build sles driver successfully."

    return 0
}

main()
{
    local drv_info=$1
    if [ "${drv_info}" == "" ] || [ "$(echo \"${drv_info}\" | grep - | wc -l)" == "0" ] || [ "${drv_info}" == "-h" ]; then
        echo "Usage: ./build_manual.sh os_type-os_version"
        echo "Example: ./build_manual.sh sles-12sp1"
        return 1
    fi

    ret=$(echo "${drv_info}" | grep "sles")
    if [ $? -eq 0 ]; then
        build_driver_sles "${drv_info}"
        return $?
    fi

    set_env ${drv_info}

    echo "Start build driver..."

    build_ko $1
    if [ $? -ne 0 ]; then
        echo "Build driver ko failed."
        return 1
    fi

    if [ $PACKAGE_TYPE = "rpm" ];then
        build_driver_rpm
    elif [ $PACKAGE_TYPE = "deb" ];then
        build_driver_deb
    else
        echo "The operating system is not supported."
    fi

    if [ $? -ne 0 ]; then
        echo "Build driver failed."
        return 1
    else
        echo "Build driver successfully."
    fi

    return 0
}

main $1

#!/bin/bash
#only for ipv4
redfishinit(){
	local user="$1"
	local password="$2"
	local ip="$3"
	curl -s -i -k --request POST -H 'Content-Type: application/json' -d '{"UserName" : "'"$user"'","Password" : "'"$password"'"}' https://"${ip}"/redfish/v1/SessionService/Sessions 
}

gettoken(){
	touch ./tokenlog
	redfishinit $user $password $ip |grep -i "X-Auth-Token" |awk '{print$2}' > ./tokenlog
}
redfishget(){
	local ip=$1
	echo $ip
	local token=$2
	echo $token
	local redfishstr=$3
	echo $redfishstr
	curl -s -i -k --request GET -H 'Content-Type: application/json' -H 'X-Auth-Token: '"$token"'' https://"${ip}""$redfishstr" | sed 's!,!\n!g' >./result/temp.log
}

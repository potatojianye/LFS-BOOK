#!/bin/bash
source ./redfish_func.sh
DATE=`date |awk '{print$2$3"-"$4}'`
pingcheck(){
	local ip=$1
	ping "$ip" -c 2 > /dev/null
	if [ $? -eq 0 ]
	then
		echo "pingcheck success"
	else
		echo "pingcheck error"
	fi
}
keys_deal(){
        local key=$1
        local start="$(grep -n "\[${key}" -A 100 "./keywords.conf" | grep -v '[:-]#' | grep "\[[a-zA-Z].*KEY" | sed -n '1p' | awk -F ':' '{print $1}')"
        local end=$(grep -n "\[${key}" -A 100 "./keywords.conf" | grep -v '[:-]#' | grep "\[[a-zA-Z].*KEY" | sed -n '2p' | awk -F '-' '{print $1}')
        echo $start $end
	let seq1=$start+1
	echo $seq1
	let seq2=$end-3
	echo $seq2
	keyinfo=`cat keywords.conf | head -n $seq2 | tail -n +$seq1`
	echo $keyinfo >./keyinfo.log
#	for i in $keyinfo
#	do
#		echo $i
#	done
}
value_deal(){
	local key=$1
	local Date=$2
	values=`cat ./keyinfo.log`
	if test $key == "Board";
	then
		grep -A 100  "FRU Device Description" ./result/temp.log >./result/${key}_info"-"${Date}.log
	else
#	echo $values
		for items in $values
		do
			grep -w $items ./result/temp.log >>./result/${key}_info"-"${Date}.log

		done
	fi
}

expect_ssh(){
	yum install -y expect &>/dev/null
	if ! expect -v &>/dev/null;
	then
		echo "expect not install or install fail"
	fi
	local user=$1
	local ip=$2
	local password=$3
	local cmd1=$4
	local cmd2=$5
	local cmd3=$6
	expect<<-EOF
		set timeout -1
		spawn ssh ${user}@${ip}	$cmd1 $cmd2 $cmd3
		expect {
			"*yes/no*" {send "yes\r";exp_continue}
			"*password*" {send "$password\r"}
		}
		expect eof
EOF
}

fru_deal(){
	local user=$1
	local ip=$2
	local password=$3
	local cmd1=$4
	local cmd2=$5
	local cmd3=$6
	expect_ssh $user $ip $password $cmd1 $cmd2 $cmd3 >./result/temp.log

}

urest_deal(){
	local ip=$1
	local user=$2
	local password=$3
	local cmd1=$4
	if test -e ./tools/bin/urest;
	then
		echo "urest installed"
	else
		tar -xzvf ./tools/iBMA_Driver-0.3.4.tar.gz &>dev/null
		tar -xzvf ./tools/uREST-Linux-V129_aarch64.tar.gz &>/dev/null
	fi
	if [ $? -eq 0 ];
	then
		./tools/bin/urest -H "$1" -U "$2" -P "$3" "$4">./result/temp.log
	fi	

}
board_deal(){
	local ip=$1
	local token=$2
	planes=`grep -i "chassisDiskBP[0-9]" ./result/temp.log |awk -F "/" '{print$NF}'|awk -F '"' '{print$1}'|sort -u`
	echo $plans
	for i in $planes
	do
		redfishget "$ip" "$token" "/redfish/v1/Chassis/1/Boards/$i"
		keys_deal "DiskBackplane" 
		value_deal "DiskBackplane" "all"
	done
	
}

pcieriser_deal(){
	local ip=$1
        local token=$2
	riser=`grep -i "mainboardPCIeRiser[0-9]" ./result/temp.log |awk -F "/" '{print$NF}'|awk -F '"' '{print$1}' |sort -u`
	echo $riser
	for j in $riser
	do
		redfishget "$ip" "$token" "/redfish/v1/Chassis/1/Boards/$j"
		keys_deal "PCIE_Riser"
		value_deal "PCIE_Riser" "all"
	done

}
pciecard_deal(){
	local ip=$1
        local token=$2
	card=`grep -i "PCIeCard[0-9]" ./result/temp.log |awk -F "/" '{print$NF}'|awk -F '"' '{print$1}' |sort -u`
	echo $card
	for k in $card
	do
		redfishget "$ip" "$token" "/redfish/v1/Chassis/1/PCIeDevices/$k"
		keys_deal "PCIECard"
		value_deal "PCIECard" "all"
	done
}

ibmc_deal(){
	local user=$1
        local ip=$2
        local password=$3
        local cmd1=$4
        local cmd2=$5
        local cmd3=$6
	expect_ssh $user $ip $password $cmd1 $cmd2 $cmd3 >./result/temp.log
	for l in iBMC_INFO Product_INFO NIC_INFO Riser_Card_INFO HDD_Backplane_INFO PSU_INFO;
	do
		keys_deal "l"
		value_deal "l" "DATE"
	done
}

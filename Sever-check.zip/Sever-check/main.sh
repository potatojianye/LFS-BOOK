#!/bin/bash

prerun(){
	mkdir -p /home/Sever-check/result
	logdir=/home/Sever-check/result
	touch /home/Sever-check/result/temp.log
	templog=/home/Sever-check/result/temp.log
	source ./com_func.sh
	source ./redfish_func.sh
	DATE=`date |awk '{print$2$3"-"$4}'`
}
prerun "$@"

productinfo(){
	local ip=$1
	local token=$2
	redfishget "$ip" "$token" "/redfish/v1/Systems/1"
	keys_deal "Product"
	value_deal "Product" "$DATE"
}

board_info(){
	local user=$1
	local ip=$2
	local password=$3
	local cmd1=$4
	local cmd2=$5
	local cmd3=$6
	fru_deal $user $ip $password $cmd1 $cmd2 $cmd3
	keys_deal "Board"
	value_deal "Board" "$DATE"
}
cpu_info(){
	local user=$1
	local ip=$2
	local password=$3
	local cmd1=$4
	urest_deal $ip $user $password $cmd1
	keys_deal "CPU"
	value_deal "CPU" "$DATE"

}
mem_info(){
	local user=$1
        local ip=$2
        local password=$3
        local cmd1=$4
        urest_deal $ip $user $password $cmd1
        keys_deal "Memory"
        value_deal "Memory" "$DATE"

}

disk_info(){
	local user=$1
        local ip=$2
        local password=$3
        local cmd1=$4
        urest_deal $ip $user $password $cmd1
        keys_deal "Disk"
        value_deal "Disk" "$DATE"
}
network_info(){
	local ip=$1
        local token=$2
        redfishget "$ip" "$token" "/redfish/v1/Chassis/1/NetworkAdapters"
        keys_deal "Network"
        value_deal "Network" "$DATE"
}
raid_info(){
	local user=$1
        local ip=$2
        local password=$3
        local cmd1=$4
        urest_deal $ip $user $password $cmd1
        keys_deal "RAID"
        value_deal "RAID" "$DATE"
}
logical_raid(){
	local user=$1
        local ip=$2
        local password=$3
        local cmd1=$4
        urest_deal $ip $user $password $cmd1
        keys_deal "Logical_Raid_Disk"
        value_deal "Logical_Raid_Disk" "$DATE"
}
psu_info(){
	local user=$1
        local ip=$2
        local password=$3
        local cmd1=$4
        urest_deal $ip $user $password $cmd1
        keys_deal "PSU"
        value_deal "PSU" "$DATE"
}
fan_info(){
	local user=$1
        local ip=$2
        local password=$3
        local cmd1=$4
        urest_deal $ip $user $password $cmd1
        keys_deal "Fan"
        value_deal "Fan" "$DATE"
}
diskbackplane_info(){
	local ip=$1
        local token=$2
	redfishget "$ip" "$token" "/redfish/v1/Chassis/1/Boards"
	board_deal $ip $token
}
pcieriser_info(){
	local ip=$1
        local token=$2
        redfishget "$ip" "$token" "/redfish/v1/Chassis/1/Boards"
	pcieriser_deal "$ip" "$token"
}
pciecard_info(){
	local ip=$1
        local token=$2
	redfishget "$ip" "$token" "/redfish/v1/Chassis/1/PCIeDevices"
	pciecard_deal "$ip" "$token"	
}
#ibmc_info(){
#	local user=$1
 #       local ip=$2
#        local password=$3
#        local cmd1=$4
#        local cmd2=$5
#        local cmd3=$6

#}
main(){
        user="$1"
        password="$2"
        ip="$3"
        pingcheck $ip
        redfishinit $user $password $ip
        gettoken $user $password $ip
        token=`cat ./tokenlog| tr -d '\r'| sed 's! !!g'`
        productinfo $ip $token
	board_info $user $ip $password "ipmcget" "-d" "fruinfo"
	cpu_info $user $ip $password getcpu
	mem_info $user $ip $password getmemory
	disk_info  $user $ip $password getpdisk
	network_info $ip $token
	raid_info $user $ip $password getraid
	logical_raid $user $ip $password getraid
	psu_info $user $ip $password getpsu
	fan_info $user $ip $password getfan
	diskbackplane_info $ip $token
	pcieriser_info $ip $token
	pciecard_info $ip $token
	ibmc_deal $user $ip $password "ipmcget" "-d" "version"
}
main $1 $2 $3

